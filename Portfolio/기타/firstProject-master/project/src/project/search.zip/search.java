package com.project.project;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class search {

	public static void main(String[] args) throws Exception {
		File file = new File("C:\\Users\\sist52\\Desktop\\Desktop\\music"); 
		MemberInfo m = new MemberInfo();
		List<String> songList = new ArrayList<>();
		//BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\sist52\\Desktop\\회원\\"+m.getId()+"\\"+"플레이리스트.txt"));
		
//		while (sc.hasNextLine())
//			
//			songList.add(sc.nextLine());
//			//System.out.println(sc.nextLine());
		
		String[] list = file.list();
		for(String a : list) {
			songList.add(a.substring(0,a.lastIndexOf(".")));
		}
//		for(int i= 0 ; i<songList.size();i++) {
//			System.out.println(songList.get(i));
//		}
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("검색:");
		
		String input =scan.nextLine(); //reader.readLine();
		File load = new File("C:\\Users\\sist52\\Desktop\\회원1\\baba39643\\baba39643playlist.txt");
		BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\sist52\\Desktop\\회원1\\baba39643\\baba39643playlist.txt"));
		List <String> matchList = new ArrayList<String>(); 
		for (String string : songList) {
            if(string.contains(input)){
                matchList.add(string+"\n");
            }
		}
		
		System.out.println(matchList);
		
		Scanner scan_1 = new Scanner(System.in);
		
		System.out.println("플레이리스트에 추가할 노래를 입력하세요");
		
		String input_1 =scan_1.nextLine();
		
		List<String> playList = new ArrayList<>();
		if(songList.contains(input_1)) {
			playList.add(input_1);
			File add = new File("C:\\Users\\sist52\\Desktop\\회원\\baba20430\\baba20430playlist.txt");
			FileOutputStream stream = new FileOutputStream(add, true);	
			String str = input_1;
			for(int i = 0; i<str.length();i++) {
				stream.write(str.charAt(i));
			}
		} 
		else { 
			System.out.println("없는 노래입니다");
		}
	
		//비회원 if else 을 넣어야하고 그 variable은 받아야함 
		Scanner scan_2 = new Scanner(System.in);
		
		System.out.println("바로 재생할 노래 제목을 입력하세요");
		
		String input_2 =scan_2.nextLine();
		
		
		if(songList.contains(input_2)) {
			System.out.println("노래를 바로 재생합니다");
		} else { 
			System.out.println("없는 노래입니다");		
		}
	
		Scanner scan_3 = new Scanner(System.in);
		
		System.out.println("비회원일경우 1분 미리듣기할 노래 제목을 입력하세요");
		
		String input_3 =scan_3.nextLine();
		
		if(songList.contains(input_3)) {
			System.out.println("1분 미리듣기 바로 재생합니다");
		} else { 
			System.out.println("없는 노래입니다");
		}
	//System.out.println(playList);
		
	}	
	
}
	